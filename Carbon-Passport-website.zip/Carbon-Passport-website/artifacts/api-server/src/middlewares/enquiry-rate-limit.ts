import type { Request, Response, NextFunction } from "express";

const WINDOW_MS = 15 * 60 * 1000;
const MAX_REQUESTS = 5;
const attempts = new Map<string, { count: number; expiresAt: number }>();

export function enquiryRateLimit(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const now = Date.now();
  const key = req.ip || "unknown";
  const current = attempts.get(key);

  if (!current || current.expiresAt <= now) {
    attempts.set(key, { count: 1, expiresAt: now + WINDOW_MS });
  } else if (current.count >= MAX_REQUESTS) {
    res.status(429).json({ error: "Please wait before sending another enquiry." });
    return;
  } else {
    current.count += 1;
  }

  if (attempts.size > 1000) {
    for (const [address, entry] of attempts) {
      if (entry.expiresAt <= now) attempts.delete(address);
    }
  }

  next();
}
