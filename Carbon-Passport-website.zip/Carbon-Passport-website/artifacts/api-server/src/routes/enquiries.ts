import { Router, type IRouter } from "express";
import { db, enquiriesTable } from "@workspace/db";
import {
  CreateEnquiryBody,
  CreateEnquiryResponse,
} from "@workspace/api-zod";
import { enquiryRateLimit } from "../middlewares/enquiry-rate-limit";

const router: IRouter = Router();

router.post("/enquiries", enquiryRateLimit, async (req, res): Promise<void> => {
  const parsed = CreateEnquiryBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.issues.length }, "Invalid website enquiry");
    res.status(400).json({ error: "Please check the enquiry fields and try again." });
    return;
  }

  try {
    const [saved] = await db
      .insert(enquiriesTable)
      .values({
        ...parsed.data,
        facilities: parsed.data.facilities ?? null,
        message: parsed.data.message ?? null,
      })
      .returning({
        id: enquiriesTable.id,
        receivedAt: enquiriesTable.receivedAt,
      });

    const response = CreateEnquiryResponse.parse({
      ...saved,
      receivedAt: saved.receivedAt.toISOString(),
      message: "Your enquiry has been received.",
    });
    res.status(201).json(response);
  } catch (error) {
    req.log.error({ err: error }, "Unable to save website enquiry");
    res.status(500).json({ error: "We could not save your enquiry. Please try again." });
  }
});

export default router;
