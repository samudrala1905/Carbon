# Carbon Passport website

React and TypeScript marketing website for Carbon Passport, a product of Saurient AI Labs Pvt. Ltd.

## Run in the pnpm workspace

Run commands from the workspace root:

```sh
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/carbon-passport dev
pnpm --filter @workspace/carbon-passport typecheck
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/carbon-passport build
```

The Carbon Passport API server and database are already part of this project. The contact form uses the generated `useCreateEnquiry` hook from `@workspace/api-client-react`; no separate API-base setup is needed.

## Content and configuration source of truth

- `src/content/page-copy.ts` holds route-specific page copy and metadata.
- `src/content/home-content.ts` and `src/content/special-page-copy.ts` hold home-page and dedicated-route copy.
- `src/content/site-config.ts` holds company details, navigation groups, footer links and enquiry interest options.
- `src/content/demo-data.ts` holds the workflow, product preview and fictional passport registry records/statuses.
- `src/content/editorial-content.ts` holds resource articles, FAQs and provisional legal copy.
- `scripts/generate-publication-metadata.mjs` emits the production sitemap only when a public origin is configured.

Update these modules rather than copying the same content into page components. Keep all passport values explicitly labelled as demonstration data.

## Publication configuration

Set `VITE_SITE_URL` to the final absolute HTTP(S) origin (for example, your actual production origin) when building for publication. The page SEO uses that origin for canonical and social URLs. The build emits an absolute-URL `sitemap.xml` and adds its absolute URL to `robots.txt` only when this variable is present. Without it, the build omits the sitemap and sitemap directive rather than shipping relative or invented URLs.

Before launch, confirm production scope, legal wording, privacy/security practices, regulatory review date and any public contact route. No customer references, accreditations, published verifications or performance claims are included.
