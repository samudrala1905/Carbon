import { existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const publicOutput = resolve(root, 'dist/public');
const sitemapPath = resolve(publicOutput, 'sitemap.xml');
const robotsPath = resolve(publicOutput, 'robots.txt');
const configuredSiteUrl = process.env.VITE_SITE_URL?.trim();

if (!existsSync(publicOutput)) {
  throw new Error(`Expected production output at ${publicOutput}; run Vite build first.`);
}

if (!configuredSiteUrl) {
  if (existsSync(sitemapPath)) rmSync(sitemapPath);
  if (existsSync(robotsPath)) {
    const robots = readFileSync(robotsPath, 'utf8')
      .split(/\r?\n/)
      .filter((line) => !/^sitemap:/i.test(line))
      .join('\n');
    writeFileSync(robotsPath, robots.trimEnd() + '\n');
  }
  console.info('VITE_SITE_URL is unset; omitted sitemap and Sitemap directive.');
  process.exit(0);
}

let siteOrigin;
try {
  const parsed = new URL(configuredSiteUrl);
  if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/') {
    throw new Error('Use an absolute HTTP(S) site origin only.');
  }
  siteOrigin = parsed.origin;
} catch (error) {
  throw new Error(`Invalid VITE_SITE_URL: ${error instanceof Error ? error.message : 'expected an absolute HTTP(S) origin'}`);
}

const paths = [
  '/', '/platform', '/how-it-works', '/connectivity', '/trust',
  '/solutions/manufacturers', '/solutions/buyers', '/solutions/verifiers', '/solutions/institutions',
  '/industries', '/cbam', '/verify', '/pricing', '/resources', '/about', '/investors', '/contact',
  '/privacy', '/terms', '/cookies', '/security', '/accessibility',
];
const urls = paths.map((path) => `  <url><loc>${siteOrigin}${path}</loc></url>`).join('\n');
writeFileSync(sitemapPath, `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`);

if (existsSync(robotsPath)) {
  const robots = readFileSync(robotsPath, 'utf8')
    .split(/\r?\n/)
    .filter((line) => !/^sitemap:/i.test(line));
  robots.push(`Sitemap: ${siteOrigin}/sitemap.xml`);
  writeFileSync(robotsPath, robots.join('\n').trimEnd() + '\n');
}
console.info(`Generated sitemap for ${siteOrigin}.`);
