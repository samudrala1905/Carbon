import { type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useCreateEnquiry, type EnquiryInput, type EnquiryInputInterest } from '@workspace/api-client-react';
import { ArrowRight, ChevronDown, CircleCheck, Layers3, Menu, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import { pages } from '@/content/page-copy';
import { company, enquiryIndustries, enquiryInterests, footerNavigation, homeAudienceLinks, legalNavigation, primaryNavigation, secondaryNavigation } from '@/content/site-config';
import { demonstrationPassports, demonstrationWorkflow, passportStatuses, productPreviewScreens } from '@/content/demo-data';
import { legalContent, resourceArticles, resourceFaqs } from '@/content/editorial-content';
import { homeContent } from '@/content/home-content';
import { specialPageCopy } from '@/content/special-page-copy';

const queryClient = new QueryClient();

function Header() {
  const [mobileOpen,setMobileOpen]=useState(false);
  const [openMenu,setOpenMenu]=useState<string|null>(null);
  useEffect(()=>{
    const closeOnEscape=(event:KeyboardEvent)=>{
      if(event.key!=='Escape')return;
      if(openMenu){setOpenMenu(null);document.querySelector<HTMLButtonElement>(`[data-menu-trigger="${openMenu}"]`)?.focus();}
      if(mobileOpen){setMobileOpen(false);document.querySelector<HTMLButtonElement>('[data-testid="button-mobile-menu"]')?.focus();}
    };
    document.addEventListener('keydown',closeOnEscape);
    return ()=>document.removeEventListener('keydown',closeOnEscape);
  },[mobileOpen,openMenu]);
  const mobileLinks: readonly (readonly [string,string])[]=[
    ...primaryNavigation.flatMap(group=>group.links.map(([label,href]):[string,string]=>[label,href])),
    ...secondaryNavigation.map(([label,href]):[string,string]=>[label,href]),
    ['Verify a Passport','/verify'],
  ];
  return <header className="topbar"><div className="wrap nav">
    <Link href="/" className="brand" aria-label={`${company.productName} home`}><span className="brand-mark"><Layers3 aria-hidden="true"/></span><span>{company.productName.toLowerCase()}</span></Link>
    <nav className="nav-links" aria-label="Main navigation">
      {primaryNavigation.map(group=><div className="nav-group" key={group.id} data-open={openMenu===group.id} onBlur={event=>{if(!event.currentTarget.contains(event.relatedTarget as Node|null))setOpenMenu(null);}}>
        <button className="nav-trigger" data-menu-trigger={group.id} aria-haspopup="true" aria-expanded={openMenu===group.id} aria-controls={`dropdown-${group.id}`} onClick={()=>setOpenMenu(openMenu===group.id?null:group.id)}>{group.label}<ChevronDown aria-hidden="true"/></button>
        <div className="dropdown" id={`dropdown-${group.id}`} hidden={openMenu!==group.id}>{group.links.map(([label,href])=><Link key={href} href={href} onClick={()=>setOpenMenu(null)}>{label}</Link>)}</div>
      </div>)}
      <Link href="/industries">Industries</Link><Link href="/resources">Resources</Link>
    </nav>
    <div className="nav-actions"><Link href="/verify" className="nav-verify">Verify a Passport</Link><Link href="/contact?interest=Product%20Demonstration" className="btn btn-mint">Book a Demo <ArrowRight aria-hidden="true"/></Link></div>
    <button className="mobile-toggle" aria-label={mobileOpen?'Close navigation':'Open navigation'} aria-expanded={mobileOpen} aria-controls="mobile-navigation" onClick={()=>setMobileOpen(!mobileOpen)} data-testid="button-mobile-menu">{mobileOpen?<X/>:<Menu/>}</button>
  </div><nav className="mobile-menu" id="mobile-navigation" aria-label="Mobile navigation" hidden={!mobileOpen}>
    {mobileLinks.map(([label,href],i)=><Link key={`${href}-${i}`} href={href} onClick={()=>setMobileOpen(false)}>{label}</Link>)}
    <Link className="btn btn-mint mobile-cta" href="/contact?interest=Product%20Demonstration" onClick={()=>setMobileOpen(false)}>Book a Demo <ArrowRight/></Link>
  </nav></header>;
}

function Footer() {
  const year=new Date().getFullYear();
  return <footer className="footer"><div className="wrap">
    <div className="footer-grid"><div className="footer-about"><Link href="/" className="brand"><span className="brand-mark"><Layers3/></span><span>{company.productName.toLowerCase()}</span></Link><p>{company.description}<br/>A product of {company.legalName}</p></div>
      {footerNavigation.map(group=><div key={group.title}><div className="footer-title">{group.title}</div><div className="footer-links">{group.links.map(([label,href])=><Link key={href} href={href}>{label}</Link>)}</div></div>)}
    </div>
    <div className="footer-qualification">{company.footerQualification}</div>
    <div className="footer-bottom"><span>© {year} {company.legalName}</span><div className="footer-legal">{legalNavigation.map(([label,href])=><Link key={href} href={href}>{label}</Link>)}</div></div>
  </div></footer>;
}

function Shell({children}:{children:ReactNode}) {
  return <div className="site"><a className="sr-only" href="#main">Skip to content</a><Header/><main id="main">{children}</main><Footer/></div>;
}

function SEO({title,description}:{title:string;description:string}) {
  useEffect(()=>{document.title=title;
    const setMeta=(selector:string,attribute:string,value:string)=>{
      let element=document.querySelector<HTMLMetaElement|HTMLLinkElement>(selector);
      if(!element){element=document.createElement(selector.startsWith('link')?'link':'meta');if(selector.startsWith('link'))element.setAttribute('rel','canonical');else {const match=selector.match(/\[(?:name|property)="([^"]+)"\]/);if(match)element.setAttribute(selector.includes('property=')?'property':'name',match[1]);}document.head.appendChild(element);}
      element.setAttribute(attribute,value);
    };
    const siteOrigin=import.meta.env.VITE_SITE_URL?new URL(import.meta.env.VITE_SITE_URL).origin:window.location.origin;
    const canonicalUrl=`${siteOrigin}${window.location.pathname}`;
    setMeta('meta[name="description"]','content',description);
    setMeta('link[rel="canonical"]','href',canonicalUrl);
    setMeta('meta[property="og:title"]','content',title);
    setMeta('meta[property="og:description"]','content',description);
    setMeta('meta[property="og:url"]','content',canonicalUrl);
    setMeta('meta[name="twitter:title"]','content',title);
    setMeta('meta[name="twitter:description"]','content',description);
  },[title,description]);return null;
}

function Eyebrow({children}:{children:ReactNode}){return <p className="eyebrow">{children}</p>}
function CTA({label='Book a Demo',interest='Product Demonstration'}:{label?:string;interest?:EnquiryInputInterest}) {
  return <Link className="btn btn-mint" href={`/contact?interest=${encodeURIComponent(interest)}`}>{label}<ArrowRight aria-hidden="true"/></Link>;
}
function PageHero({kicker,title,lead,cta,interest}:{kicker:string;title:string;lead:string;cta?:string;interest?:EnquiryInputInterest}) {
  return <section className="page-hero"><div className="wrap"><Eyebrow>{kicker}</Eyebrow><h1>{title}</h1><p className="lead">{lead}</p>{cta&&(cta==='View a Sample Passport'?<Link className="btn btn-mint" href="/verify">{cta}<ArrowRight/></Link>:<CTA label={cta} interest={interest}/>)}</div></section>;
}

function ProductPreview(){const [tab,setTab]=useState(0);const item=productPreviewScreens[tab];return <div className="preview" aria-label="Illustrative Carbon Passport product preview"><div className="preview-top"><span>CARBON PASSPORT / WORKSPACE</span><span>DEMONSTRATION</span></div><div className="preview-body">
  <div className="preview-tabs" role="tablist" aria-label="Product preview screens">{productPreviewScreens.map((p,i)=><button key={p.name} role="tab" aria-selected={tab===i} className="preview-tab" onClick={()=>setTab(i)}>{p.name}</button>)}</div>
  <div role="tabpanel" aria-label={item.name}><span className="data-label">{item.caption}</span><div className="preview-data"><div className="preview-box"><span className="data-label">{item.label}</span><div className="data-value">{item.value}</div><div className="data-sub">{item.sub}</div></div><div className="preview-box"><span className="data-label">RECORD CONTEXT</span><strong style={{fontSize:14}}>Illustrative product record</strong><div className="data-sub">Boundary, method and supporting evidence remain attached to the record.</div></div></div></div>
  </div></div>}

function HeroVisual(){return <div className="hero-visual"><div className="visual-head"><span>Carbon workflow / 01</span><span className="demo-tag">Product demonstration</span></div><div className="visual-flow"><div className="flow-stack"><div className="flow-node"><strong>Industrial activity</strong><small>ENERGY · OUTPUT · INPUTS</small></div><div className="flow-node"><strong>Supplier records</strong><small>SOURCE + PERIOD</small></div></div><div className="flow-arrow"><ArrowRight/></div><div className="flow-stack"><div className="flow-node highlight"><strong>Emissions workspace</strong><small>BOUNDARY · METHOD · UNIT</small></div><div className="flow-node"><strong>Evidence review</strong><small>CHECKS ≠ VERIFICATION</small></div></div></div><div className="visual-record"><strong>PRODUCT CARBON PASSPORT</strong><span>VERSIONED RECORD →</span></div><div className="visual-foot">ILLUSTRATIVE WORKFLOW · NOT A LIVE VERIFIED RESULT</div></div>}

function Home(){return <Shell><SEO title={homeContent.title} description={homeContent.description}/>
  <section className="hero"><div className="wrap hero-grid"><div><Eyebrow>{homeContent.hero.eyebrow}</Eyebrow><h1>{homeContent.hero.headline}</h1><p className="lead">{homeContent.hero.description}</p><div className="hero-actions"><CTA/><Link className="btn btn-outline" href="/how-it-works">See How It Works <ArrowRight/></Link></div><p className="hero-note">A product of {company.legalName}</p></div><HeroVisual/></div></section>
  <section className="section"><div className="wrap two-col"><div><Eyebrow>{homeContent.evidenceIntro.eyebrow}</Eyebrow><h2>{homeContent.evidenceIntro.headline}</h2></div><p className="lead" style={{fontSize:16,margin:0}}>{homeContent.evidenceIntro.description}</p></div><div className="wrap value-grid" style={{marginTop:44}}>{homeContent.valueAreas.map(([n,title,body])=><div className="value-item" key={n}><div className="value-index">{n}</div><h3>{title}</h3><p>{body}</p></div>)}</div></section>
  <section className="section section-dark"><div className="wrap"><div className="section-head"><Eyebrow>{homeContent.workflow.eyebrow}</Eyebrow><h2>{homeContent.workflow.headline}</h2><p>{homeContent.workflow.description}</p></div><div className="steps-strip">{homeContent.workflow.steps.map((title,i)=><div className="step-mini" key={title}><strong>{title}</strong><span>STEP {String(i+1).padStart(2,'0')}</span></div>)}</div><div style={{marginTop:34}}><Link className="btn btn-outline" href="/how-it-works" style={{color:'#fff',borderColor:'#566579'}}>Explore all eight steps <ArrowRight/></Link></div></div></section>
  <section className="section"><div className="wrap"><div className="section-head"><Eyebrow>{homeContent.preview.eyebrow}</Eyebrow><h2>{homeContent.preview.headline}</h2><p>{homeContent.preview.description}</p></div><ProductPreview/></div></section>
  <section className="section section-compact"><div className="wrap two-col"><div><Eyebrow>{homeContent.audiences.eyebrow}</Eyebrow><h2>{homeContent.audiences.headline}</h2><p className="lead" style={{fontSize:15}}>{homeContent.audiences.description}</p></div><div className="solution-grid">{homeAudienceLinks.map(([title,href])=><Link key={href} className="solution-card" href={href}><span><h3>{title}</h3><p>Explore the workflow for this role.</p></span><ArrowRight className="arrow"/></Link>)}</div></div></section>
  <section className="section section-dark"><div className="wrap two-col"><div><Eyebrow>{homeContent.connectivity.eyebrow}</Eyebrow><h2>{homeContent.connectivity.headline}</h2><p>{homeContent.connectivity.description}</p><Link href="/connectivity" className="btn btn-outline" style={{color:'#fff',borderColor:'#566579'}}>Explore connectivity <ArrowRight/></Link></div><div className="flowline">{homeContent.connectivity.stages.map(([label,detail])=><div className="flowline-item" key={label} style={{background:'#142133',borderColor:'#344255'}}><span className="data-label">{label}</span><p style={{fontSize:12,margin:0,color:'#d2dce7'}}>{detail}</p></div>)}</div></div></section>
  <section className="section"><div className="wrap two-col"><div><Eyebrow>{homeContent.trust.eyebrow}</Eyebrow><h2>{homeContent.trust.headline}</h2><p className="lead" style={{fontSize:16}}>{homeContent.trust.description}</p><Link className="text-link" href="/trust">How review and lifecycle work <ArrowRight/></Link></div><div className="panel"><div className="data-label">RECORD CONTEXT / DEMONSTRATION</div>{homeContent.trust.records.map(([label,detail])=><div className="list-row" key={label}><h3>{label}</h3><p>{detail}</p></div>)}</div></div></section>
  <section className="band"><div className="wrap band-inner"><h2>{homeContent.closing.headline}</h2><CTA label={homeContent.closing.cta}/></div></section>
</Shell>}

function HowItWorks(){const [step,setStep]=useState(0);const current=demonstrationWorkflow[step];const content=specialPageCopy.howItWorks;return <Shell><SEO title={content.title} description={content.description}/><PageHero kicker={content.kicker} title={content.headline} lead={content.lead}/>
  <section className="section"><div className="wrap"><div className="workflow-layout"><div className="workflow-list" role="list" aria-label="Carbon record workflow steps">{demonstrationWorkflow.map((s,i)=><button key={s.title} className="workflow-btn" aria-current={step===i?'step':undefined} onClick={()=>setStep(i)} data-testid={`workflow-step-${i+1}`}><b>{String(i+1).padStart(2,'0')}</b>{s.title}</button>)}</div><div className="panel workflow-detail"><div><Eyebrow>STEP {String(step+1).padStart(2,'0')} / 08</Eyebrow><h3>{current.title}</h3><div className="list-row"><h3 style={{fontSize:12}}>Information entered</h3><p>{current.entered}</p></div><div className="list-row"><h3 style={{fontSize:12}}>What happens</h3><p>{current.happens}</p></div><div className="list-row"><h3 style={{fontSize:12}}>Output produced</h3><p>{current.output}</p></div><div style={{display:'flex',gap:10,marginTop:20}}><button className="btn btn-outline" onClick={()=>setStep(Math.max(0,step-1))} disabled={step===0}>Previous</button><button className="btn" onClick={()=>setStep(Math.min(7,step+1))} disabled={step===7}>Next step <ArrowRight/></button></div></div><div className="workflow-screen"><span className="data-label">ILLUSTRATIVE RECORD / DEMONSTRATION</span>{current.screen.map(([a,b])=><div className="screen-row" key={a}><span>{a}</span><span>{b}</span></div>)}<p style={{fontSize:10,color:'#a8b8ca',marginTop:20}}>Illustrative interface only. Not a production record.</p></div></div></div></div></section>
  <section className="section section-dark"><div className="wrap two-col"><div><Eyebrow>PASSPORT LIFECYCLE</Eyebrow><h2>{content.lifecycleHeadline}</h2><p>{content.lifecycleLead}</p></div><div><div className="status-list">{passportStatuses.map(s=><span className="status-chip" style={{color:'#f5f7fa',borderColor:'#526174'}} key={s}>{s}</span>)}</div><p style={{marginTop:24}}>{content.verifiedClarification}</p></div></div></section></Shell>}

function Verify(){const [value,setValue]=useState('');const [searched,setSearched]=useState(false);const [record,setRecord]=useState<typeof demonstrationPassports[number]|null>(null);const [error,setError]=useState('');const content=specialPageCopy.verify;
 const lookup=(id:string)=>{const found=demonstrationPassports.find(r=>r.id.toLowerCase()===id.trim().toLowerCase());setValue(id);setSearched(true);setRecord(found??null);setError(id.trim()?content.noMatch:content.emptySearch);};
 function submit(e:FormEvent){e.preventDefault();lookup(value);}
  return <Shell><SEO title={content.title} description={content.description}/><PageHero kicker={content.kicker} title={content.headline} lead={content.lead}/><section className="section"><div className="wrap"><div className="callout"><strong>{content.registryNotice}</strong> {content.registryDescription}</div>
  <form className="verify-form" onSubmit={submit}><label className="sr-only" htmlFor="passport-id">Passport ID</label><input id="passport-id" value={value} onChange={e=>setValue(e.target.value)} placeholder={content.idPlaceholder} data-testid="input-passport-id"/><button className="btn" type="submit" data-testid="button-search-passport">Check record <ArrowRight/></button></form>
  {searched&&(!record?<div className="form-error" role="status">{error}</div>:<div className="panel registry-record" aria-live="polite">{record.status==='Revoked'&&<div className="record-alert">{content.revokedNotice}</div>}<div style={{display:'flex',justifyContent:'space-between',gap:16,flexWrap:'wrap',alignItems:'center'}}><div><span className="demo-tag">Fictional demonstration data</span><h2 style={{fontSize:28,marginTop:16}}>{record.product}</h2><div className="record-id">{record.id}</div></div><span className="status-chip">{record.status}</span></div>
   <div className="record-grid">{[['Organisation',record.organisation],['Reporting period',record.period],['Declared unit',record.unit],['Footprint',record.footprint],['Boundary',record.boundary],['Methodology',record.method],['Version',record.version],['Review status',record.status],['Issue date',record.issued]].map(([k,v])=><div className="record-field" key={k}><small>{k}</small><strong>{v}</strong></div>)}</div>
   {record.newer&&<div className="callout" style={{marginTop:18}}>This version has been superseded. The newer demonstration record is <button onClick={()=>lookup(record.newer!)} style={{padding:0,border:0,background:'none',color:'#0879a8',textDecoration:'underline',cursor:'pointer'}}>{record.newer}</button>.</div>}
    <p className="form-note" style={{marginTop:18}}>{content.lookupQualification}</p></div>)}
    <div style={{marginTop:44}}><h3>{content.sampleRecordsHeading}</h3><p className="form-note">{content.sampleRecordsInstruction}</p><div className="status-list">{demonstrationPassports.filter(r=>r.id!== 'CP-DEMO-REV-005').map(r=><button className="status-chip" key={r.id} onClick={()=>lookup(r.id)}>{r.status} · {r.id}</button>)}</div></div>
 </div></section></Shell>;
}

function Contact(){const [location,setLocation]=useLocation();const content=specialPageCopy.contact;const interestFromQuery=new URLSearchParams(window.location.search).get('interest')||'';const initialInterest=enquiryInterests.find(x=>x.toLowerCase()===interestFromQuery.toLowerCase())||'Product Demonstration';
 const [interest,setInterest]=useState<EnquiryInputInterest>(initialInterest);const [receipt,setReceipt]=useState<{id:string;receivedAt:string;message:string}|null>(null);const mutation=useCreateEnquiry();const [localError,setLocalError]=useState('');
 useEffect(()=>{setInterest(enquiryInterests.find(x=>x.toLowerCase()===new URLSearchParams(window.location.search).get('interest')?.toLowerCase())||'Product Demonstration');},[location]);
 function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setLocalError('');const form=e.currentTarget;const data=new FormData(form);const optionalFacilities=data.get('facilities')?.toString().trim();
   const payload:EnquiryInput={fullName:String(data.get('fullName')).trim(),workEmail:String(data.get('workEmail')).trim(),company:String(data.get('company')).trim(),role:String(data.get('role')).trim(),country:String(data.get('country')).trim(),industry:String(data.get('industry')).trim(),interest,facilities:optionalFacilities?Number(optionalFacilities):undefined,reportingObjective:String(data.get('reportingObjective')).trim(),message:String(data.get('message')||'').trim()||undefined,marketingConsent:data.get('marketingConsent')==='on'};
   const facilities=payload.facilities;
   if(facilities!==undefined&&facilities!==null&&(!Number.isInteger(facilities)||facilities<1||facilities>100000)){setLocalError('Enter a whole number of facilities between 1 and 100,000.');return;}
   mutation.mutate({data:payload},{onSuccess:(r)=>{setReceipt(r);form.reset();},onError:(err)=>{setLocalError(err instanceof Error?err.message:'Your enquiry could not be saved. Please try again.');}});
 }
 return <Shell><SEO title={content.title} description={content.description}/><PageHero kicker={content.kicker} title={content.headline} lead={content.lead}/>
 <section className="section"><div className="wrap two-col" style={{alignItems:'start'}}><div><Eyebrow>START A CONVERSATION</Eyebrow><h2>{content.formIntro}</h2><p className="lead" style={{fontSize:15}}>{content.formDescription}</p><div className="dark-callout"><strong>{content.demonstrationTitle}</strong><p style={{fontSize:13,marginBottom:0}}>{content.demonstrationNotice}</p></div><p className="form-note" style={{marginTop:22}}>{content.noPublicContact}</p></div>
 <div className="panel form-card">{receipt?<div className="form-success" role="status" aria-live="polite"><CircleCheck color="#178353"/><h2 style={{fontSize:27,marginTop:14}}>Enquiry received</h2><p>{receipt.message}</p><div className="data-label">RECEIPT ID</div><div className="record-id">{receipt.id}</div><p className="form-note">Received {new Date(receipt.receivedAt).toLocaleString('en-GB')}</p><button className="btn btn-outline" onClick={()=>{setReceipt(null);setLocalError('');}}>Submit another enquiry</button></div>:
 <form onSubmit={submit}><div className="form-grid">
  <div className="field"><label htmlFor="fullName">Full name *</label><input id="fullName" name="fullName" required minLength={2} maxLength={120} autoComplete="name"/></div>
  <div className="field"><label htmlFor="workEmail">Work email *</label><input id="workEmail" name="workEmail" type="email" required maxLength={254} autoComplete="email"/></div>
  <div className="field"><label htmlFor="company">Company or institution *</label><input id="company" name="company" required minLength={2} maxLength={160} autoComplete="organization"/></div>
  <div className="field"><label htmlFor="role">Role *</label><input id="role" name="role" required minLength={2} maxLength={120} autoComplete="organization-title"/></div>
  <div className="field"><label htmlFor="country">Country *</label><input id="country" name="country" required minLength={2} maxLength={100} autoComplete="country-name"/></div>
   <div className="field"><label htmlFor="industry">Industry *</label><select id="industry" name="industry" required defaultValue=""><option value="" disabled>Select an industry</option>{enquiryIndustries.map(i=><option key={i}>{i}</option>)}</select></div>
   <div className="field"><label htmlFor="interest">Interest area *</label><select id="interest" value={interest} onChange={e=>setInterest(e.target.value as EnquiryInputInterest)} required>{enquiryInterests.map(i=><option key={i}>{i}</option>)}</select></div>
  <div className="field"><label htmlFor="facilities">Number of facilities <span className="form-note">(optional)</span></label><input id="facilities" name="facilities" type="number" min="1" max="100000" step="1" inputMode="numeric"/></div>
  <div className="field full"><label htmlFor="reportingObjective">Reporting objective *</label><textarea id="reportingObjective" name="reportingObjective" required minLength={5} maxLength={2000} placeholder="What carbon information or reporting workflow are you working towards?"/></div>
  <div className="field full"><label htmlFor="message">Message <span className="form-note">(optional)</span></label><textarea id="message" name="message" maxLength={4000} placeholder="Any additional context for the discussion?"/></div>
  </div><label className="checkline"><input type="checkbox" name="marketingConsent"/><span>{content.marketingConsent}</span></label>
 {localError&&<div className="form-error" role="alert">{localError}</div>}{mutation.isError&&!localError&&<div className="form-error" role="alert">We could not save your enquiry. Please check your connection and try again.</div>}
 <p className="form-note">{content.formDisclosure.replace('Saurient AI Labs Pvt. Ltd.',company.legalName)}</p>
 <button className="btn btn-mint" type="submit" disabled={mutation.isPending} data-testid="button-submit-enquiry">{mutation.isPending?content.submitting:content.submit}{!mutation.isPending&&<ArrowRight/>}</button>
 {mutation.isPending&&<p className="form-note" role="status">{content.pending}</p>}
 </form>}</div></div></section></Shell>;
}

function Resources(){const [article,setArticle]=useState<number|null>(null);const active=article===null?null:resourceArticles[article];const content=specialPageCopy.resources;return <Shell><SEO title={content.title} description={content.description}/><PageHero kicker={content.kicker} title={content.headline} lead={content.lead}/>
 {active?<section className="section"><div className="wrap article"><button className="btn btn-outline" onClick={()=>setArticle(null)}><ArrowRight style={{transform:'rotate(180deg)'}}/> All resources</button><p className="eyebrow" style={{marginTop:32}}>{active.tag}</p><h1 style={{fontSize:46}}>{active.title}</h1><p className="lead" style={{fontSize:17}}>{active.body}</p>{active.sections.map(([h,b])=><section key={h}><h2>{h}</h2><p>{b}</p></section>)}</div></section>:<section className="section"><div className="wrap"><div className="content-grid">{resourceArticles.map((r,i)=><article className="card resource-card" key={r.title}><div className="card-number">{r.tag}</div><h3>{r.title}</h3><p>{r.body}</p><button className="btn btn-outline" onClick={()=>setArticle(i)}>Read guide <ArrowRight/></button></article>)}</div><div style={{marginTop:76,maxWidth:820}}><Eyebrow>FREQUENTLY ASKED QUESTIONS</Eyebrow><h2>{content.faqHeadline}</h2><div className="faq">{resourceFaqs.map(([question,answer])=><details key={question}><summary>{question}</summary><p>{answer}</p></details>)}</div></div></div></section>}</Shell>}

function Legal({path}:{path:string}){const page=legalContent[path];const content=specialPageCopy.legal;return <Shell><SEO title={page.title} description={page.desc}/><PageHero kicker={content.kicker} title={page.heading} lead={page.desc}/><section className="section"><div className="wrap article"><div className="legal-notice"><strong>{content.provisionalLabel}</strong> {content.provisionalNotice}</div>{page.body.map((p,i)=><p key={i}>{p}</p>)}</div></section></Shell>}

function Generic({path}:{path:string}){const page=pages[path];return <Shell><SEO title={page.title} description={page.description}/><PageHero kicker={page.kicker} title={page.headline} lead={page.lead} cta={page.cta} interest={page.interest}/><section className="section"><div className="wrap">
 {path==='/platform'&&<div className="callout" style={{marginBottom:35}}>Corporate inventories, product footprints and regulatory embedded-emissions calculations have different boundaries and methods. Keep them distinct in the record.</div>}
 {path==='/connectivity'&&<><div className="flowline">{[['METERS & SENSORS','Electricity · fuels · relevant process measurements'],['GATEWAY OR INTERFACE','Subject to site assessment'],['ACTIVITY RECORDS','Production context · approved imports'],['EMISSIONS CALCULATION','Factors · boundary · allocation'],['PASSPORT','Versioned product record']].map(([t,b])=><div className="flowline-item" key={t}><span className="data-label">{t}</span><p style={{fontSize:12,margin:0}}>{b}</p></div>)}</div><div className="callout" style={{marginTop:26}}>A meter reading alone is not a product footprint. Emissions calculations require appropriate factors, reporting boundaries, production context and allocation choices.</div></>}
 {path==='/solutions/manufacturers'&&<><div className="section-head"><Eyebrow>A PRACTICAL PILOT</Eyebrow><h2>Keep the first scope focused.</h2></div><div className="flowline">{[['01','One facility'],['02','One product'],['03','Defined boundary'],['04','Evidence package'],['05','Reviewed passport']].map(([n,t])=><div className="flowline-item" key={n}><span className="data-label">STEP {n}</span><h3>{t}</h3></div>)}</div></>}
 {path==='/cbam'&&<div className="callout" style={{marginBottom:36,fontSize:18}}><strong>A Carbon Passport supports preparation. It is not a CBAM certificate.</strong></div>}
 <div className="content-grid">{page.sections.map((s,i)=><article className="card" key={s.title}><div className="card-number">{String(i+1).padStart(2,'0')} / {page.kicker}</div><h3>{s.title}</h3><p>{s.body}</p></article>)}</div>
 {path==='/cbam'&&<div className="panel" style={{marginTop:34}}><Eyebrow>OFFICIAL GUIDANCE</Eyebrow><p style={{fontSize:14,color:'#475569'}}>Consult current official European Commission guidance for the applicable goods, reporting obligations and requirements. Regulatory review date: not configured.</p><a className="btn btn-outline" href="https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en" target="_blank" rel="noreferrer">European Commission CBAM guidance <ArrowRight/></a></div>}
 {path==='/trust'&&<div className="callout" style={{marginTop:35}}>Automated checks can highlight missing fields, inconsistent units and potential anomalies. They do not replace independent verification.</div>}
 {path==='/industries'&&<p className="form-note" style={{marginTop:26}}>CBAM applicability depends on covered goods and applicable product codes, not just an industry label.</p>}
 {path==='/investors'&&<div className="hero-actions" style={{marginTop:35}}><CTA label="Request an Investor Briefing" interest="Investment Discussion"/><CTA label="Explore a Strategic Partnership" interest="Verification Partnership"/></div>}
 {page.cta&&path!='/investors'&&<div className="band" style={{marginTop:65,borderRadius:16}}><div className="band-inner"><h2>Discuss a scope that fits your workflow.</h2>{path==='/trust'?<Link className="btn" href="/verify">View a Sample Passport <ArrowRight/></Link>:<CTA label={page.cta} interest={page.interest}/>}</div></div>}
 </div></section></Shell>}

function NotFound(){const content=specialPageCopy.notFound;return <Shell><SEO title={content.title} description={content.description}/><section className="page-hero"><div className="wrap"><Eyebrow>{content.kicker}</Eyebrow><h1>{content.headline}</h1><p className="lead">{content.lead}</p><div className="hero-actions"><Link className="btn btn-mint" href="/">Go to home <ArrowRight/></Link><Link className="btn btn-outline" href="/platform">Explore the platform</Link></div></div></section></Shell>}

function RoutedErrorBoundary({children}:{children:ReactNode}){const [location]=useLocation();return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>}
function Router(){return <RoutedErrorBoundary><Switch>
 <Route path="/" component={Home}/><Route path="/platform" component={()=> <Generic path="/platform"/>}/><Route path="/how-it-works" component={HowItWorks}/><Route path="/connectivity" component={()=> <Generic path="/connectivity"/>}/><Route path="/trust" component={()=> <Generic path="/trust"/>}/>
 <Route path="/solutions/manufacturers" component={()=> <Generic path="/solutions/manufacturers"/>}/><Route path="/solutions/buyers" component={()=> <Generic path="/solutions/buyers"/>}/><Route path="/solutions/verifiers" component={()=> <Generic path="/solutions/verifiers"/>}/><Route path="/solutions/institutions" component={()=> <Generic path="/solutions/institutions"/>}/>
 <Route path="/industries" component={()=> <Generic path="/industries"/>}/><Route path="/cbam" component={()=> <Generic path="/cbam"/>}/><Route path="/verify" component={Verify}/><Route path="/pricing" component={()=> <Generic path="/pricing"/>}/><Route path="/resources" component={Resources}/><Route path="/about" component={()=> <Generic path="/about"/>}/><Route path="/investors" component={()=> <Generic path="/investors"/>}/><Route path="/contact" component={Contact}/>
 {Object.keys(legalContent).map(path=><Route key={path} path={path} component={()=> <Legal path={path}/>}/>)}<Route component={NotFound}/>
 </Switch></RoutedErrorBoundary>}
function App(){return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,'')}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>}
export default App;
