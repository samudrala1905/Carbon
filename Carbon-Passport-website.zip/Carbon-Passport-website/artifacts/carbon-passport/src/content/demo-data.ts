export const productPreviewScreens = [
  { name: 'Organisation Overview', caption: 'FACILITY RECORD', label: 'Reporting period', value: '2025 · DEMO', sub: 'Illustrative workspace only' },
  { name: 'Product Footprint', caption: 'PRODUCT RECORD', label: 'Declared footprint', value: '1.42 kg CO₂e', sub: 'per kg product · demo value' },
  { name: 'Evidence Review', caption: 'REVIEW WORKSPACE', label: 'Data readiness', value: 'In review', sub: 'Readiness is not verification' },
  { name: 'Carbon Passport', caption: 'PASSPORT REGISTRY', label: 'Lifecycle status', value: 'Reviewed', sub: 'Fictional demonstration record' },
] as const;

export const passportStatuses = ['Draft', 'Under Review', 'Reviewed', 'Verified', 'Superseded', 'Revoked'] as const;

export const demonstrationWorkflow = [
  { title:'Register the organisation',entered:'Organisation identity, facilities and responsible users.',happens:'Create the operating context in which product information will be assembled.',output:'An organisation and facility workspace.',screen:[['Organisation','DEMO WORKSPACE'],['Facility','Illustrative site'],['Access','Role-based workflow']]},
  { title:'Define the product and boundary',entered:'Product description, declared unit, reporting period and included processes.',happens:'Set the scope of the record before activity data or calculations are interpreted.',output:'A defined product record boundary.',screen:[['Product','Sample alloy sheet'],['Declared unit','1 kg product'],['Boundary','Defined for demonstration']]},
  { title:'Collect activity and supplier data',entered:'Energy, production, material inputs, supplier information and source evidence.',happens:'Organise records with period, unit, owner and source references.',output:'A structured activity and evidence set.',screen:[['Electricity','Source attached'],['Production','Period linked'],['Supplier input','Illustrative / pending']]},
  { title:'Calculate the footprint',entered:'Activity values, factors, conversion, allocation and methodology choices.',happens:'Apply the selected method within the defined boundary and document assumptions.',output:'An illustrative product footprint and calculation context.',screen:[['Declared footprint','1.42 kg CO₂e / kg'],['Status','DEMONSTRATION VALUE'],['Method','Illustrative only']]},
  { title:'Check data readiness',entered:'Required fields, units, source presence and data consistency.',happens:'Automated checks may flag gaps, inconsistent units and potential anomalies.',output:'A readiness view and list of follow-up items.',screen:[['Required fields','Readiness check'],['Open item','Supplier evidence'],['Meaning','Not verification']]},
  { title:'Submit for review',entered:'The prepared record, supporting sources and calculation context.',happens:'A separate reviewer can inspect the submission and request clarification.',output:'An under-review record with questions and response history.',screen:[['Submission','Under Review'],['Reviewer','Independent role'],['Clarification','Track response']]},
  { title:'Issue the passport',entered:'Reviewed scope, conclusion where applicable and release permissions.',happens:'Issue a versioned record with its status and date. “Verified” applies only to independent verification within the stated scope.',output:'A Carbon Passport record with clear lifecycle state.',screen:[['Record version','v1.0 / DEMO'],['Review status','Reviewed'],['Verified','Only if independently verified']]},
  { title:'Share and maintain',entered:'Recipient, disclosure settings and subsequent record changes.',happens:'Share a controlled view; issue a newer version or revoke a record when required.',output:'A shareable record whose lifecycle remains visible.',screen:[['Sharing','Controlled disclosure'],['New version','Supersedes prior'],['Withdrawal','Revoked status visible']]},
] as const;

export type DemonstrationPassport = {
  id: string;
  status: string;
  product: string;
  organisation: string;
  period: string;
  unit: string;
  footprint: string;
  boundary: string;
  method: string;
  version: string;
  issued: string;
  newer?: string;
};

export const demonstrationPassports: DemonstrationPassport[] = [
  {id:'CP-DEMO-REV-001',status:'Reviewed',product:'Sample alloy sheet',organisation:'Demonstration Metals Ltd. (fictional)',period:'2025 reporting period',unit:'1 kg product',footprint:'1.42 kg CO₂e / kg',boundary:'Illustrative defined-gate boundary',method:'Illustrative product calculation; method demonstration only',version:'v1.0',issued:'Demonstration issue date: 14 May 2025'},
  {id:'CP-DEMO-VER-002',status:'Independently verified demo',product:'Sample mineral binder',organisation:'Example Materials Works (fictional)',period:'2024 reporting period',unit:'1 tonne product',footprint:'386 kg CO₂e / tonne',boundary:'Illustrative cradle-to-gate boundary',method:'Fictional method context for interface demonstration',version:'v1.0',issued:'Demonstration issue date: 08 March 2025'},
  {id:'CP-DEMO-REVW-003',status:'Under Review',product:'Sample rolled aluminium',organisation:'Illustrative Alloy Company (fictional)',period:'2025 reporting period',unit:'1 tonne product',footprint:'2,180 kg CO₂e / tonne',boundary:'Demonstration facility boundary',method:'Illustrative calculation; awaiting review',version:'v1.0',issued:'Demonstration submission date: 22 June 2025'},
  {id:'CP-DEMO-SUP-004',status:'Superseded',product:'Sample process fertiliser',organisation:'Fictional Process Industries (fictional)',period:'2024 reporting period',unit:'1 tonne product',footprint:'1,074 kg CO₂e / tonne',boundary:'Illustrative production boundary',method:'Demonstration methodology context',version:'v1.0',issued:'Demonstration issue date: 11 February 2025',newer:'CP-DEMO-REV-005'},
  {id:'CP-DEMO-REV-005',status:'Reviewed',product:'Sample process fertiliser',organisation:'Fictional Process Industries (fictional)',period:'2024 reporting period',unit:'1 tonne product',footprint:'1,091 kg CO₂e / tonne',boundary:'Illustrative production boundary',method:'Demonstration methodology context; revised record',version:'v2.0',issued:'Demonstration issue date: 02 April 2025'},
  {id:'CP-DEMO-WDR-006',status:'Revoked',product:'Sample processed grain',organisation:'Demonstration Food Systems (fictional)',period:'2024 reporting period',unit:'1 tonne product',footprint:'620 kg CO₂e / tonne',boundary:'Illustrative facility boundary',method:'Demonstration record; withdrawn',version:'v1.0',issued:'Demonstration issue date: 03 January 2025'},
];
