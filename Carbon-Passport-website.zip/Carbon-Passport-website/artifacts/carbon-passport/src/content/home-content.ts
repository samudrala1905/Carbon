export const homeContent = {
  title: 'Carbon Passport | From Industrial Data to a Trusted Carbon Record',
  description: 'Connect industrial activity data, emissions calculations and supporting evidence in a reviewable, versioned Carbon Passport workflow.',
  hero: {
    eyebrow: 'INDUSTRIAL CARBON INTELLIGENCE',
    headline: 'From industrial data to a trusted carbon record.',
    description: 'Bring energy, production and supplier data into a connected carbon workflow. Calculate product emissions, organise supporting evidence and share a digital Carbon Passport with a clear review status.',
  },
  evidenceIntro: {
    eyebrow: 'THE RECORD MATTERS',
    headline: 'A carbon number is only as useful as the record behind it.',
    description: 'A reported footprint needs more than a result. It needs a defined product and boundary, relevant activity data, an understandable method and supporting evidence that can be reviewed in context.',
  },
  valueAreas: [
    ['01', 'Connected Activity Data', 'Bring energy, output and supplier inputs into a structured record.'],
    ['02', 'Transparent Calculations', 'Keep units, boundaries, factors and allocation choices visible.'],
    ['03', 'Structured Review', 'Track readiness, clarification and conclusions without conflating them.'],
    ['04', 'Controlled Sharing', 'Share a scoped, versioned record with its status in view.'],
  ] as const,
  workflow: {
    eyebrow: 'ONE CONNECTED WORKFLOW',
    headline: 'From the site record to a controlled share.',
    description: 'Each step keeps its own information and responsibility clear.',
    steps: ['Set Up', 'Collect', 'Calculate', 'Review', 'Share'],
  },
  preview: {
    eyebrow: 'PRODUCT PREVIEW',
    headline: 'One record. The context to read it.',
    description: 'Explore illustrative screens from the product workflow. All values and records shown are demonstration data.',
  },
  audiences: {
    eyebrow: 'BUILT FOR THE VALUE CHAIN',
    headline: 'Different roles. A shared record, with clear boundaries.',
    description: 'Give each participant the context relevant to their work—without implying that every audience has the same responsibilities.',
  },
  connectivity: {
    eyebrow: 'SATTRIC+ CONNECTIVITY',
    headline: 'Connect the factory to the carbon record.',
    description: 'SaTTric+ is a proposed industrial connectivity layer, subject to site assessment and deployment scope. Connect operational context to the records that inform carbon calculations.',
    stages: [
      ['METER', 'Energy + process'],
      ['INTERFACE', 'Gateway or import'],
      ['RECORD', 'Activity + output'],
      ['CALCULATION', 'Factors + boundary'],
      ['PASSPORT', 'Versioned record'],
    ] as const,
  },
  trust: {
    eyebrow: 'TRUST THROUGH CONTEXT',
    headline: 'Show what is behind the result.',
    description: 'Automated checks can highlight missing fields, inconsistent units and potential anomalies. They do not replace independent verification.',
    records: [
      ['Scope', 'Product, boundary and reporting period are explicit.'],
      ['Evidence', 'Supporting sources stay associated with the record.'],
      ['Status', 'Reviewed, verified, superseded and revoked mean different things.'],
    ] as const,
  },
  closing: {
    headline: 'Make your next carbon conversation evidence-led.',
    cta: 'Talk to our team',
  },
} as const;
