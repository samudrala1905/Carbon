import type { EnquiryInputInterest } from '@workspace/api-client-react';

export const company = {
  productName: 'Carbon Passport',
  legalName: 'Saurient AI Labs Pvt. Ltd.',
  description: 'Industrial carbon intelligence, evidence and product traceability.',
  footerQualification: 'Carbon Passport supports carbon data management and review workflows. Regulatory acceptance, independent verification and carbon credit eligibility depend on the applicable requirements and authorised bodies.',
};

export const primaryNavigation = [
  {
    id: 'platform',
    label: 'Platform',
    links: [
      ['Overview', '/platform'],
      ['How It Works', '/how-it-works'],
      ['SaTTric+ Connectivity', '/connectivity'],
      ['Trust and Verification', '/trust'],
    ],
  },
  {
    id: 'solutions',
    label: 'Solutions',
    links: [
      ['Manufacturers and Exporters', '/solutions/manufacturers'],
      ['Buyers and Supply Chains', '/solutions/buyers'],
      ['Verifiers', '/solutions/verifiers'],
      ['Governments and Institutions', '/solutions/institutions'],
    ],
  },
  {
    id: 'company',
    label: 'Company',
    links: [
      ['About Saurient', '/about'],
      ['Investors', '/investors'],
      ['Partnerships', '/contact?interest=Verification%20Partnership'],
    ],
  },
] as const;

export const secondaryNavigation = [
  ['Industries', '/industries'],
  ['CBAM Data Readiness', '/cbam'],
  ['Pricing', '/pricing'],
  ['Resources', '/resources'],
  ['About Saurient', '/about'],
  ['Investors', '/investors'],
  ['Contact', '/contact'],
] as const;

export const footerNavigation = [
  {
    title: 'Platform',
    links: [['Overview', '/platform'], ['How it works', '/how-it-works'], ['Connectivity', '/connectivity'], ['Trust', '/trust'], ['Verify a Passport', '/verify']],
  },
  {
    title: 'For your role',
    links: [['Manufacturers', '/solutions/manufacturers'], ['Buyers', '/solutions/buyers'], ['Verifiers', '/solutions/verifiers'], ['Institutions', '/solutions/institutions'], ['Industries', '/industries']],
  },
  {
    title: 'Company',
    links: [['Resources', '/resources'], ['About Saurient', '/about'], ['Investors', '/investors'], ['Contact', '/contact'], ['Pricing', '/pricing']],
  },
] as const;

export const legalNavigation = [
  ['Privacy', '/privacy'],
  ['Terms', '/terms'],
  ['Cookies', '/cookies'],
  ['Security', '/security'],
  ['Accessibility', '/accessibility'],
] as const;

export const enquiryInterests: EnquiryInputInterest[] = [
  'Product Demonstration',
  'Manufacturer Pilot',
  'Supplier Programme',
  'Verification Partnership',
  'Institutional Deployment',
  'Investment Discussion',
];

export const enquiryIndustries = [
  'Iron and steel',
  'Aluminium',
  'Cement',
  'Fertilisers',
  'Agri-processing',
  'Other manufacturing',
  'Government or institution',
  'Verification services',
  'Other',
] as const;

export const homeAudienceLinks = [
  ['Manufacturers and Exporters', '/solutions/manufacturers'],
  ['Buyers and Supply Chains', '/solutions/buyers'],
  ['Verification Agencies', '/solutions/verifiers'],
  ['Governments and Institutions', '/solutions/institutions'],
] as const;
