import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const enquiriesTable = pgTable("website_enquiries", {
  id: uuid("id").primaryKey().defaultRandom(),
  fullName: text("full_name").notNull(),
  workEmail: text("work_email").notNull(),
  company: text("company").notNull(),
  role: text("role").notNull(),
  country: text("country").notNull(),
  industry: text("industry").notNull(),
  interest: text("interest").notNull(),
  facilities: integer("facilities"),
  reportingObjective: text("reporting_objective").notNull(),
  message: text("message"),
  marketingConsent: boolean("marketing_consent").notNull().default(false),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertEnquirySchema = createInsertSchema(enquiriesTable).omit({
  id: true,
  receivedAt: true,
});
export type InsertEnquiry = z.infer<typeof insertEnquirySchema>;
export type Enquiry = typeof enquiriesTable.$inferSelect;
