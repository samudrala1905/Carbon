# Saurient Integration Hub frontend reference
Open index.html in a browser. Eight standalone HTML pages contain their own CSS and JavaScript and work without a build or backend. Keep the files together so tab links work.

## Included pages
Connections, Mapping Studio, Sync Controls, Import Jobs, Exceptions, Telemetry, Manual Entry, Bulk Upload.

## Working interactions
Tab navigation, source configuration preview, mapping preview, sync simulation, job detail, error/source/template CSV downloads, correction history, manual form validation, basic CSV validation/import simulation and internal-menu handoff drawers.

## Backend handoff
These are frontend references, not changes to carbon-poc. Convert the shared shell, badges, tables, forms and drawer to existing React components. Map menu destinations to actual routes. Replace fixtures with tenant-scoped API queries; persist mapping revisions, source records, jobs, findings and correction history. Enforce permissions and issuance safeguards on the server.

CSV support is intentionally limited to simple unquoted values. Replace with a robust CSV/Excel parser for production; validate again server-side. Demo evidence IDs do not prove document authenticity. Schedules, connections and draft saves have no live effect. Downloads contain sample data. Internal menu drawers describe integration points; they do not implement those modules.

## Visual theme
Navy #0B111D, mint #18E88F / #00D99A, cyan #00BFEA, light workspace #F6F8FB, rounded white cards. Native Arial fallback, no external fonts or scripts.
