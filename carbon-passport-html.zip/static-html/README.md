# Carbon Passport — Standalone HTML Pages

Self-contained static pages (no React/build) styled with Tailwind CDN + shared mock data.
Open `index.html` in any modern browser (internet needed for the Tailwind & fonts CDNs).

## Pages
- `index.html` — Organisation Profile
- `facilities.html` → `facility-detail.html?id=FAC-GH-001`
- `processes.html` → `process-detail.html?id=PROC-GH-006`
- `periods.html` → `period-detail.html?id=RP-2025-FY`
- `approvals.html` — Approvals queue + request detail modal
- `users.html` — Users & Roles + permission matrix
- `localisation.html` — Localisation with market presets

## Shared assets (`/assets`)
- `style.css` — fonts + modal styles
- `tw-config.js` — Tailwind font config
- `data.js` — all mock data (window.CP)
- `ui.js` — shared nav, badges, field helpers (window.CPUI)

## React static build
A production build of the full React app is also available at `/app/frontend/build`
(generated via `yarn build`). Serve that folder with any static host.
