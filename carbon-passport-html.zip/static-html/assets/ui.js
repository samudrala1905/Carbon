// Shared UI helpers for Carbon Passport standalone HTML pages.
window.CPUI = (function () {
  const links = [
    { href: "index.html", label: "Profile", key: "profile" },
    { href: "facilities.html", label: "Facilities", key: "facilities" },
    { href: "processes.html", label: "Processes", key: "processes" },
    { href: "periods.html", label: "Periods", key: "periods" },
    { href: "approvals.html", label: "Approvals", key: "approvals" },
    { href: "users.html", label: "Users", key: "users" },
    { href: "localisation.html", label: "Locale", key: "localisation" },
  ];

  function nav(active) {
    return `
    <div class="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-30">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <a href="index.html" class="flex items-center gap-2.5">
          <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-800 text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>
          </div>
          <div class="flex flex-col leading-none">
            <span class="font-heading font-bold text-sm text-slate-900">Carbon Passport</span>
            <span class="text-[10px] font-mono uppercase tracking-widest text-slate-400">Organisation Registry</span>
          </div>
        </a>
        <nav class="flex items-center gap-1 flex-wrap justify-end">
          ${links.map((l) => `<a href="${l.href}" class="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${l.key === active ? "bg-emerald-50 text-emerald-800" : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"}">${l.label}</a>`).join("")}
        </nav>
      </div>
    </div>`;
  }

  function pill(text, tone) {
    const tones = {
      emerald: "bg-emerald-50 text-emerald-800 border-emerald-300",
      amber: "bg-amber-50 text-amber-800 border-amber-300",
      sky: "bg-sky-50 text-sky-800 border-sky-300",
      indigo: "bg-indigo-50 text-indigo-800 border-indigo-300",
      violet: "bg-violet-50 text-violet-800 border-violet-300",
      rose: "bg-rose-50 text-rose-700 border-rose-300",
      orange: "bg-orange-50 text-orange-800 border-orange-300",
      slate: "bg-slate-100 text-slate-600 border-slate-300",
    };
    return `<span class="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold font-mono ${tones[tone] || tones.slate}">${text}</span>`;
  }

  const statusTone = {
    Active: "emerald", Onboarding: "amber", Inactive: "slate", Verified: "emerald",
    OPEN: "emerald", "DATA LOCKED": "amber", SUBMITTED: "sky", VERIFIED: "indigo", CLOSED: "slate",
    Draft: "amber", "Under Review": "sky",
    "Awaiting Approval": "amber", "Awaiting Verifier": "indigo", "Awaiting Authorised Approver": "violet",
    Approved: "emerald", Rejected: "rose", Returned: "orange", Invited: "amber", Suspended: "rose",
  };
  const riskTone = { Low: "emerald", Medium: "amber", High: "rose" };
  const scopeTone = (s) => (String(s).includes("1/2") ? "slate" : String(s).includes("1") ? "orange" : String(s).includes("2") ? "sky" : String(s).includes("3") ? "indigo" : "slate");

  function statusPill(s) { return pill(s, statusTone[s]); }
  function riskPill(r) { return pill(r, riskTone[r]); }
  function scopePill(s) {
    const tones = { emerald: "bg-emerald-50 text-emerald-800 border-emerald-300", amber: "bg-amber-50 text-amber-800 border-amber-300", sky: "bg-sky-50 text-sky-800 border-sky-300", indigo: "bg-indigo-50 text-indigo-800 border-indigo-300", orange: "bg-orange-50 text-orange-800 border-orange-300", slate: "bg-slate-100 text-slate-600 border-slate-300" };
    return `<span class="inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-mono font-semibold ${tones[scopeTone(s)]}">${s}</span>`;
  }

  function field(label, value, mono, span) {
    return `<div class="flex flex-col gap-1 p-3 rounded-lg bg-slate-50/70 border border-slate-100 ${span ? "sm:col-span-2" : ""}">
      <span class="text-[11px] font-mono font-medium tracking-wider uppercase text-slate-500">${label}</span>
      <span class="text-sm text-slate-900 break-words ${mono ? "font-mono font-medium" : "font-medium"}">${value || '<span class="text-slate-400 italic font-normal">Not provided</span>'}</span>
    </div>`;
  }

  function completeness(v) {
    const color = v >= 90 ? "bg-emerald-500" : v >= 70 ? "bg-amber-500" : "bg-slate-400";
    return `<div class="flex items-center gap-2"><div class="h-1.5 w-16 rounded-full bg-slate-100 overflow-hidden"><div class="h-full rounded-full ${color}" style="width:${v}%"></div></div><span class="text-xs font-mono text-slate-500">${v}%</span></div>`;
  }

  function mount(active) {
    document.getElementById("nav").innerHTML = nav(active);
  }

  // basic modal open/close
  function openModal(id) { document.getElementById(id).classList.add("open"); }
  function closeModal(id) { document.getElementById(id).classList.remove("open"); }

  return { mount, nav, pill, statusPill, riskPill, scopePill, scopeTone, field, completeness, openModal, closeModal };
})();
